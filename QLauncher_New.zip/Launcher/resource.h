//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Launcher.rc
//
#define IDD_LAUNCHER_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_CONNECT                     1000
#define IDC_SELECT_MYTYPE               1001
#define IDC_COMBO_SELECT                1002
#define IDC_TYPE_CANCEL                 1003
#define IDC_LIST_SERVER_INFO            1004
#define IDC_IPADDRESS                   1005
#define IDC_DISCONNECT                  1006
#define IDC_SEND_FILELIST_              1007
#define IDC_LIST_CLIENT_FILE_LST        1008
#define IDC_ADD_FILE_LIST               1009
#define IDC_DEL_LIST                    1010
#define IDC_LIST_SERVER_VIEW_CLIENT_STATE 1011
#define IDC_LETS_RUN_CLIENT             1012
#define IDC_LETS_OFF_CLIENT             1013
#define IDC_LETS_OFF_CLIENT2            1014
#define IDC_LETS_EXIT_CLIENT            1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
