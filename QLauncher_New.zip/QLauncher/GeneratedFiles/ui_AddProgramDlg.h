/********************************************************************************
** Form generated from reading UI file 'AddProgramDlg.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPROGRAMDLG_H
#define UI_ADDPROGRAMDLG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AddProgramDlg
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *ProgramLineEdit;
    QPushButton *SelectProgramButton;
    QLabel *label;

    void setupUi(QDialog *AddProgramDlg)
    {
        if (AddProgramDlg->objectName().isEmpty())
            AddProgramDlg->setObjectName(QString::fromUtf8("AddProgramDlg"));
        AddProgramDlg->resize(400, 65);
        buttonBox = new QDialogButtonBox(AddProgramDlg);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(50, 30, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        ProgramLineEdit = new QLineEdit(AddProgramDlg);
        ProgramLineEdit->setObjectName(QString::fromUtf8("ProgramLineEdit"));
        ProgramLineEdit->setGeometry(QRect(60, 10, 291, 20));
        SelectProgramButton = new QPushButton(AddProgramDlg);
        SelectProgramButton->setObjectName(QString::fromUtf8("SelectProgramButton"));
        SelectProgramButton->setGeometry(QRect(357, 9, 31, 23));
        label = new QLabel(AddProgramDlg);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 13, 56, 12));

        retranslateUi(AddProgramDlg);
        QObject::connect(buttonBox, SIGNAL(accepted()), AddProgramDlg, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), AddProgramDlg, SLOT(reject()));

        QMetaObject::connectSlotsByName(AddProgramDlg);
    } // setupUi

    void retranslateUi(QDialog *AddProgramDlg)
    {
        AddProgramDlg->setWindowTitle(QApplication::translate("AddProgramDlg", "Add Program", 0, QApplication::UnicodeUTF8));
        SelectProgramButton->setText(QApplication::translate("AddProgramDlg", "...", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("AddProgramDlg", "\355\224\204\353\241\234\352\267\270\353\236\250", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class AddProgramDlg: public Ui_AddProgramDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPROGRAMDLG_H
