/********************************************************************************
** Form generated from reading UI file 'qlauncher.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QLAUNCHER_H
#define UI_QLAUNCHER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>
#include <QtGui/QTreeView>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_QLauncherClass
{
public:
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QTreeView *treeConnectionList;
    QTreeView *treeProgramList;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_3;
    QListWidget *listLog;
    QVBoxLayout *verticalLayout;
    QPushButton *btnAdd;
    QPushButton *btnDelete;
    QPushButton *btnOn;
    QPushButton *btnOnAll;
    QPushButton *btnOff;
    QPushButton *btnOffAll;
    QPushButton *btnPowerOff;
    QPushButton *btnReboot;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_5;
    QCheckBox *checkServerList;
    QPushButton *btnServerConn;
    QTableWidget *tableServerList;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *checkMacList;
    QPushButton *btnPower;
    QTableWidget *tableMac;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *edTargetIp;
    QLineEdit *edTargetPort;
    QPushButton *btnSaveConf;

    void setupUi(QDialog *QLauncherClass)
    {
        if (QLauncherClass->objectName().isEmpty())
            QLauncherClass->setObjectName(QString::fromUtf8("QLauncherClass"));
        QLauncherClass->resize(490, 587);
        QLauncherClass->setWindowOpacity(1);
        verticalLayout_2 = new QVBoxLayout(QLauncherClass);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        treeConnectionList = new QTreeView(QLauncherClass);
        treeConnectionList->setObjectName(QString::fromUtf8("treeConnectionList"));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        QBrush brush1(QColor(240, 240, 240, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        treeConnectionList->setPalette(palette);
        treeConnectionList->setEditTriggers(QAbstractItemView::NoEditTriggers);
        treeConnectionList->setProperty("showDropIndicator", QVariant(false));
        treeConnectionList->setAlternatingRowColors(true);

        horizontalLayout->addWidget(treeConnectionList);

        treeProgramList = new QTreeView(QLauncherClass);
        treeProgramList->setObjectName(QString::fromUtf8("treeProgramList"));
        treeProgramList->setEditTriggers(QAbstractItemView::NoEditTriggers);
        treeProgramList->setAlternatingRowColors(true);

        horizontalLayout->addWidget(treeProgramList);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        listLog = new QListWidget(QLauncherClass);
        listLog->setObjectName(QString::fromUtf8("listLog"));
        listLog->setAlternatingRowColors(true);

        verticalLayout_3->addWidget(listLog);


        horizontalLayout_3->addLayout(verticalLayout_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        btnAdd = new QPushButton(QLauncherClass);
        btnAdd->setObjectName(QString::fromUtf8("btnAdd"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnAdd->sizePolicy().hasHeightForWidth());
        btnAdd->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(btnAdd);

        btnDelete = new QPushButton(QLauncherClass);
        btnDelete->setObjectName(QString::fromUtf8("btnDelete"));
        sizePolicy.setHeightForWidth(btnDelete->sizePolicy().hasHeightForWidth());
        btnDelete->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(btnDelete);

        btnOn = new QPushButton(QLauncherClass);
        btnOn->setObjectName(QString::fromUtf8("btnOn"));

        verticalLayout->addWidget(btnOn);

        btnOnAll = new QPushButton(QLauncherClass);
        btnOnAll->setObjectName(QString::fromUtf8("btnOnAll"));

        verticalLayout->addWidget(btnOnAll);

        btnOff = new QPushButton(QLauncherClass);
        btnOff->setObjectName(QString::fromUtf8("btnOff"));

        verticalLayout->addWidget(btnOff);

        btnOffAll = new QPushButton(QLauncherClass);
        btnOffAll->setObjectName(QString::fromUtf8("btnOffAll"));

        verticalLayout->addWidget(btnOffAll);

        btnPowerOff = new QPushButton(QLauncherClass);
        btnPowerOff->setObjectName(QString::fromUtf8("btnPowerOff"));

        verticalLayout->addWidget(btnPowerOff);

        btnReboot = new QPushButton(QLauncherClass);
        btnReboot->setObjectName(QString::fromUtf8("btnReboot"));

        verticalLayout->addWidget(btnReboot);


        horizontalLayout_3->addLayout(verticalLayout);


        verticalLayout_2->addLayout(horizontalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        checkServerList = new QCheckBox(QLauncherClass);
        checkServerList->setObjectName(QString::fromUtf8("checkServerList"));
        checkServerList->setChecked(true);

        horizontalLayout_5->addWidget(checkServerList);

        btnServerConn = new QPushButton(QLauncherClass);
        btnServerConn->setObjectName(QString::fromUtf8("btnServerConn"));

        horizontalLayout_5->addWidget(btnServerConn);


        verticalLayout_4->addLayout(horizontalLayout_5);

        tableServerList = new QTableWidget(QLauncherClass);
        tableServerList->setObjectName(QString::fromUtf8("tableServerList"));

        verticalLayout_4->addWidget(tableServerList);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        checkMacList = new QCheckBox(QLauncherClass);
        checkMacList->setObjectName(QString::fromUtf8("checkMacList"));

        horizontalLayout_4->addWidget(checkMacList);

        btnPower = new QPushButton(QLauncherClass);
        btnPower->setObjectName(QString::fromUtf8("btnPower"));

        horizontalLayout_4->addWidget(btnPower);


        verticalLayout_4->addLayout(horizontalLayout_4);

        tableMac = new QTableWidget(QLauncherClass);
        tableMac->setObjectName(QString::fromUtf8("tableMac"));

        verticalLayout_4->addWidget(tableMac);


        verticalLayout_2->addLayout(verticalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        edTargetIp = new QLineEdit(QLauncherClass);
        edTargetIp->setObjectName(QString::fromUtf8("edTargetIp"));

        horizontalLayout_2->addWidget(edTargetIp);

        edTargetPort = new QLineEdit(QLauncherClass);
        edTargetPort->setObjectName(QString::fromUtf8("edTargetPort"));

        horizontalLayout_2->addWidget(edTargetPort);

        btnSaveConf = new QPushButton(QLauncherClass);
        btnSaveConf->setObjectName(QString::fromUtf8("btnSaveConf"));

        horizontalLayout_2->addWidget(btnSaveConf);


        verticalLayout_2->addLayout(horizontalLayout_2);


        retranslateUi(QLauncherClass);

        QMetaObject::connectSlotsByName(QLauncherClass);
    } // setupUi

    void retranslateUi(QDialog *QLauncherClass)
    {
        QLauncherClass->setWindowTitle(QApplication::translate("QLauncherClass", "QLauncher", 0, QApplication::UnicodeUTF8));
        btnAdd->setText(QApplication::translate("QLauncherClass", "\354\266\224\352\260\200", 0, QApplication::UnicodeUTF8));
        btnDelete->setText(QApplication::translate("QLauncherClass", "\354\202\255\354\240\234", 0, QApplication::UnicodeUTF8));
        btnOn->setText(QApplication::translate("QLauncherClass", "On", 0, QApplication::UnicodeUTF8));
        btnOnAll->setText(QApplication::translate("QLauncherClass", "On All", 0, QApplication::UnicodeUTF8));
        btnOff->setText(QApplication::translate("QLauncherClass", "Off", 0, QApplication::UnicodeUTF8));
        btnOffAll->setText(QApplication::translate("QLauncherClass", "Off All", 0, QApplication::UnicodeUTF8));
        btnPowerOff->setText(QApplication::translate("QLauncherClass", "\354\240\204\354\233\220 \353\201\204\352\270\260", 0, QApplication::UnicodeUTF8));
        btnReboot->setText(QApplication::translate("QLauncherClass", "\354\236\254\353\266\200\355\214\205", 0, QApplication::UnicodeUTF8));
        checkServerList->setText(QApplication::translate("QLauncherClass", "Server List", 0, QApplication::UnicodeUTF8));
        btnServerConn->setText(QApplication::translate("QLauncherClass", "\354\204\234\353\262\204 \354\240\221\354\206\215", 0, QApplication::UnicodeUTF8));
        checkMacList->setText(QApplication::translate("QLauncherClass", "WOL Mac address List", 0, QApplication::UnicodeUTF8));
        btnPower->setText(QApplication::translate("QLauncherClass", "\354\240\204\354\233\220 \354\274\234\352\270\260", 0, QApplication::UnicodeUTF8));
        btnSaveConf->setText(QApplication::translate("QLauncherClass", "ip\354\204\244\354\240\225\354\240\200\354\236\245", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QLauncherClass: public Ui_QLauncherClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QLAUNCHER_H
