/****************************************************************************
** Meta object code from reading C++ file 'LauncherRole.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../LauncherRole.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'LauncherRole.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_LauncherRole[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      37,   14,   13,   13, 0x05,
     115,   13,   13,   13, 0x05,
     136,   13,   13,   13, 0x05,
     165,  161,   13,   13, 0x05,

 // slots: signature, parameters, type, tag, flags
     189,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_LauncherRole[] = {
    "LauncherRole\0\0,,pClient,strGroupName\0"
    "updateProgramStateSignal(unsigned char,unsigned char,LauncherClient*,Q"
    "String)\0"
    "connectionTimerFin()\0connectionTimerRestart()\0"
    "log\0writeLogSignal(QString)\0OnConnection()\0"
};

void LauncherRole::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LauncherRole *_t = static_cast<LauncherRole *>(_o);
        switch (_id) {
        case 0: _t->updateProgramStateSignal((*reinterpret_cast< unsigned char(*)>(_a[1])),(*reinterpret_cast< unsigned char(*)>(_a[2])),(*reinterpret_cast< LauncherClient*(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 1: _t->connectionTimerFin(); break;
        case 2: _t->connectionTimerRestart(); break;
        case 3: _t->writeLogSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->OnConnection(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData LauncherRole::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject LauncherRole::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_LauncherRole,
      qt_meta_data_LauncherRole, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &LauncherRole::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *LauncherRole::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *LauncherRole::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LauncherRole))
        return static_cast<void*>(const_cast< LauncherRole*>(this));
    return QObject::qt_metacast(_clname);
}

int LauncherRole::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void LauncherRole::updateProgramStateSignal(unsigned char _t1, unsigned char _t2, LauncherClient * _t3, QString _t4)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LauncherRole::connectionTimerFin()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void LauncherRole::connectionTimerRestart()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void LauncherRole::writeLogSignal(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
static const uint qt_meta_data_ServerRole[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   12,   11,   11, 0x0a,
      39,   12,   11,   11, 0x0a,
      59,   12,   11,   11, 0x0a,
      81,   12,   11,   11, 0x0a,
     110,  104,   11,   11, 0x0a,
     138,   12,   11,   11, 0x0a,
     160,   12,   11,   11, 0x0a,
     185,   11,   11,   11, 0x0a,
     200,   12,   11,   11, 0x0a,
     222,  217,   11,   11, 0x0a,
     258,   12,   11,   11, 0x0a,
     283,  277,   11,   11, 0x0a,
     314,  277,   11,   11, 0x0a,
     342,   12,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ServerRole[] = {
    "ServerRole\0\0clicked\0onButtonSlot(bool)\0"
    "offButtonSlot(bool)\0OnAllButtonSlot(bool)\0"
    "OffAllButtonSlot(bool)\0index\0"
    "treeSelectSlot(QModelIndex)\0"
    "powerButtonSlot(bool)\0powerOffButtonSlot(bool)\0"
    "OnConnection()\0rebootSlot(bool)\0item\0"
    "treeItemChangedSlot(QStandardItem*)\0"
    "saveIpConfig(bool)\0state\0"
    "changeCheckServerListSlot(int)\0"
    "changeCheckMacListSlot(int)\0"
    "btnServerConnSlot(bool)\0"
};

void ServerRole::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ServerRole *_t = static_cast<ServerRole *>(_o);
        switch (_id) {
        case 0: _t->onButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->offButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->OnAllButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->OffAllButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->treeSelectSlot((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 5: _t->powerButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->powerOffButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->OnConnection(); break;
        case 8: _t->rebootSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->treeItemChangedSlot((*reinterpret_cast< QStandardItem*(*)>(_a[1]))); break;
        case 10: _t->saveIpConfig((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->changeCheckServerListSlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->changeCheckMacListSlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->btnServerConnSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ServerRole::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ServerRole::staticMetaObject = {
    { &LauncherRole::staticMetaObject, qt_meta_stringdata_ServerRole,
      qt_meta_data_ServerRole, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ServerRole::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ServerRole::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ServerRole::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ServerRole))
        return static_cast<void*>(const_cast< ServerRole*>(this));
    return LauncherRole::qt_metacast(_clname);
}

int ServerRole::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LauncherRole::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}
static const uint qt_meta_data_ClientRole[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   12,   11,   11, 0x0a,
      40,   12,   11,   11, 0x0a,
      60,   11,   11,   11, 0x0a,
      75,   12,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ClientRole[] = {
    "ClientRole\0\0clicked\0addButtonSlot(bool)\0"
    "delButtonSlot(bool)\0OnConnection()\0"
    "saveIpConfig(bool)\0"
};

void ClientRole::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ClientRole *_t = static_cast<ClientRole *>(_o);
        switch (_id) {
        case 0: _t->addButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->delButtonSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->OnConnection(); break;
        case 3: _t->saveIpConfig((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ClientRole::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ClientRole::staticMetaObject = {
    { &LauncherRole::staticMetaObject, qt_meta_stringdata_ClientRole,
      qt_meta_data_ClientRole, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ClientRole::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ClientRole::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ClientRole::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ClientRole))
        return static_cast<void*>(const_cast< ClientRole*>(this));
    return LauncherRole::qt_metacast(_clname);
}

int ClientRole::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LauncherRole::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
