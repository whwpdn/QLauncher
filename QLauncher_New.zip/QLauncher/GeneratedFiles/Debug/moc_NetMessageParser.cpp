/****************************************************************************
** Meta object code from reading C++ file 'NetMessageParser.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../NetMessageParser.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'NetMessageParser.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NetMessageParser[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_NetMessageParser[] = {
    "NetMessageParser\0"
};

void NetMessageParser::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NetMessageParser::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NetMessageParser::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_NetMessageParser,
      qt_meta_data_NetMessageParser, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NetMessageParser::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NetMessageParser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NetMessageParser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NetMessageParser))
        return static_cast<void*>(const_cast< NetMessageParser*>(this));
    return QThread::qt_metacast(_clname);
}

int NetMessageParser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_NetTcpMessageParser[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_NetTcpMessageParser[] = {
    "NetTcpMessageParser\0"
};

void NetTcpMessageParser::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NetTcpMessageParser::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NetTcpMessageParser::staticMetaObject = {
    { &NetMessageParser::staticMetaObject, qt_meta_stringdata_NetTcpMessageParser,
      qt_meta_data_NetTcpMessageParser, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NetTcpMessageParser::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NetTcpMessageParser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NetTcpMessageParser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NetTcpMessageParser))
        return static_cast<void*>(const_cast< NetTcpMessageParser*>(this));
    return NetMessageParser::qt_metacast(_clname);
}

int NetTcpMessageParser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = NetMessageParser::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
