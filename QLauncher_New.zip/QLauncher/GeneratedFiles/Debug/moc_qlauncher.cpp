/****************************************************************************
** Meta object code from reading C++ file 'qlauncher.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../qlauncher.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qlauncher.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QLauncher[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   11,   10,   10, 0x0a,
      63,   33,   10,   10, 0x0a,
     139,   10,   10,   10, 0x0a,
     152,   10,   10,   10, 0x0a,
     177,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_QLauncher[] = {
    "QLauncher\0\0msg\0writeLog(QString)\0"
    ",ucState,pClient,strGroupName\0"
    "updateProgramStateSlot(unsigned char,unsigned char,LauncherClient*,QSt"
    "ring)\0"
    "updateSlot()\0connectionTimerFinSlot()\0"
    "connectionTimerReStartSlot()\0"
};

void QLauncher::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        QLauncher *_t = static_cast<QLauncher *>(_o);
        switch (_id) {
        case 0: _t->writeLog((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->updateProgramStateSlot((*reinterpret_cast< unsigned char(*)>(_a[1])),(*reinterpret_cast< unsigned char(*)>(_a[2])),(*reinterpret_cast< LauncherClient*(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 2: _t->updateSlot(); break;
        case 3: _t->connectionTimerFinSlot(); break;
        case 4: _t->connectionTimerReStartSlot(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData QLauncher::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject QLauncher::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_QLauncher,
      qt_meta_data_QLauncher, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QLauncher::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QLauncher::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QLauncher::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QLauncher))
        return static_cast<void*>(const_cast< QLauncher*>(this));
    return QDialog::qt_metacast(_clname);
}

int QLauncher::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
