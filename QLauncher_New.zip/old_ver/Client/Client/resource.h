//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Client.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_IPADDRESS2                  1001
#define IDC_IPADDRESS                   1001
#define ID_BUTTON_CONNECT               1002
#define IDCTEST                         1003
#define IDCDISCONNECT                   1003
#define ID_BUTTON_ADD                   1005
#define ID_BUTTON_SEND                  1006
#define IDC_LIST                        1007
#define IDC_TEXT                        1008
#define ID_BUTTON_CANCEL                1008
#define IDC_EDIT1                       1009
#define IDC_EDIT_INFO                   1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
